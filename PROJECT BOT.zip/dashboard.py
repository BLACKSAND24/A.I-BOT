# dashboard.py
import os, time, threading, logging
import streamlit as st
import joblib
from trading import TradingEngine
from notifier import send_telegram_message
import pandas as pd
from train_model import fetch_data, create_features
from config import TRADING_SYMBOL, MODEL_FILE

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

st.set_page_config(page_title="Trading Dashboard", layout="wide")
st.title("📈 Trading Bot Dashboard")

engine = TradingEngine()
symbol = st.sidebar.text_input("Symbol", value="BTCUSDT").upper()
mode = st.sidebar.selectbox("Mode", options=["paper","live"])
refresh_rate = st.sidebar.slider("Refresh every (sec)", 2, 60, 8)

price_ph = st.empty()
signal_ph = st.empty()
trades_ph = st.empty()

def update_loop():
    while True:
        try:
            price = engine.fetch_ticker(symbol)['last']
            sig = engine.compute_signal(engine.fetch_ohlcv_df(symbol, '1m', 200))
            price_ph.metric(f"{symbol} Price", f"{price:.8f}")
            signal_ph.markdown(f"**Signal:** {sig.upper()}")
            trades = engine.get_trade_log()[-20:]
            df = pd.DataFrame(trades)
            trades_ph.dataframe(df)
        except Exception as e:
            logger.warning(f"dashboard loop error: {e}")
        time.sleep(refresh_rate)

if "thread" not in st.session_state:
    t = threading.Thread(target=update_loop, daemon=True)
    t.start()
    st.session_state["thread"] = t

st.subheader("Manual Trade")
col1, col2 = st.columns(2)
with col1:
    amount = st.number_input("Buy amount (quote)", value=10.0)
    if st.button("Market Buy"):
        res = engine.place_order(symbol, 'buy', quote_amount=amount, mode=mode)
        st.write(res)
with col2:
    qty = st.number_input("Sell qty (base)", value=0.0)
    if st.button("Market Sell"):
        res = engine.place_order(symbol, 'sell', size=qty, mode=mode)
        st.write(res)

st.subheader("ML Model")
@st.cache_data
def load_data():
    df = fetch_data(TRADING_SYMBOL)
    if not df.empty:
        df = create_features(df)
    return df

@st.cache_data
def load_model():
    try:
        return joblib.load(MODEL_FILE)
    except Exception:
        return None

df = load_data()
model = load_model()

if df is None or df.empty:
    st.error("No data. Check API keys.")
else:
    st.subheader("Price")
    st.line_chart(df["close"])
    st.subheader("Data")
    st.dataframe(df.tail(30))
    if model:
        st.success("ML model loaded")
        if st.button("Run backtest"):
            import backtest_ml
            backtest_ml.backtest()
    else:
        st.warning("Model not available. Run train_model.py")
