import json
import logging
from flask import Flask, render_template, jsonify
from position_manager import PositionManager
from config import DASHBOARD_PORT, DASHBOARD_HOST

logger = logging.getLogger(__name__)
app = Flask(__name__)
pos_mgr = PositionManager("positions.json")

@app.route("/api/positions", methods=["GET"])
def get_positions():
    """Return all positions (open + closed)."""
    summary = pos_mgr.summary()
    return jsonify(summary)

@app.route("/api/positions/open", methods=["GET"])
def get_open_positions():
    """Return open positions only."""
    open_pos = pos_mgr.get_open_positions()
    return jsonify({"positions": [p.to_dict() for p in open_pos]})

@app.route("/api/stats", methods=["GET"])
def get_stats():
    """Return portfolio stats."""
    summary = pos_mgr.summary()
    open_pos = summary["open_count"]
    closed_pos = summary["closed_count"]
    total_pnl = summary["total_pnl"]
    
    return jsonify({
        "open_positions": open_pos,
        "closed_positions": closed_pos,
        "total_pnl": total_pnl,
        "win_rate": (sum(1 for p in summary.get("closed_positions", []) if p.get("pnl", 0) > 0) / max(closed_pos, 1)) * 100 if closed_pos > 0 else 0,
    })

@app.route("/")
def dashboard():
    """Serve dashboard HTML."""
    return render_template("dashboard.html")

if __name__ == "__main__":
    app.run(host=DASHBOARD_HOST, port=DASHBOARD_PORT, debug=True)