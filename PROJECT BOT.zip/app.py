# app.py
import os
import logging
from flask import Flask, render_template, request, jsonify
from trading import TradingEngine

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = Flask(__name__, template_folder='templates', static_folder='static')
engine = TradingEngine()

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/api/price')
def price():
    symbol = request.args.get('symbol', 'BTCUSDT').upper()
    t = engine.fetch_ticker(symbol)
    return jsonify(t)

@app.route('/api/signal')
def signal():
    symbol = request.args.get('symbol', 'BTCUSDT').upper()
    df = engine.fetch_ohlcv_df(symbol, timeframe='1m', limit=200)
    sig = engine.compute_signal(df)
    return jsonify({'symbol':symbol,'signal': sig})

@app.route('/api/order', methods=['POST'])
def order():
    data = request.json
    side = data.get('side')
    symbol = data.get('symbol','BTCUSDT').upper()
    mode = data.get('mode','paper')
    # Accept either quote_amount (buy) or size (sell)
    quote_amount = data.get('quote_amount')
    size = data.get('size')
    res = engine.place_order(symbol=symbol, side=side, size=size, quote_amount=quote_amount, mode=mode)
    return jsonify(res)

@app.route('/api/trades')
def trades():
    return jsonify(engine.get_trade_log())

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=int(os.getenv('PORT',5000)))
